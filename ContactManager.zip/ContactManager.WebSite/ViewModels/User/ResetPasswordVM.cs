﻿namespace ContactManager.WebSite.ViewModels.User {
    public class ResetPasswordVM {
        public string UserName { get; set; }
        public string NewPassword { get; set; }
    }
}
